// mailer.com by jass - the movable box that lives inside the page.
// opened / closed by the toolbar icon, stays on the page across navigations while a run is going.
(async () => {
  if (window.__mailerPanel) return;
  window.__mailerPanel = true;

  const UI_KEY = 'mr_ui';
  const DATA_KEY = 'mr_data';
  const RUN_KEY = 'mr_run';

  const STEP_LABELS = [
    'open the sign-up link',
    'enter first & last name',
    'click next',
    'pick birth month, day, year + gender',
    'click next',
    'username page: pick "create your own" if shown',
    'enter username',
    'click next',
    'tick show password + enter password',
    'click next',
    'final check'
  ];
  const SEL_KEYS = [
    ['first', 'first name'], ['last', 'last name'], ['month', 'month'], ['day', 'day'], ['year', 'year'],
    ['gender', 'gender'], ['create', 'create-own option'], ['user', 'username'], ['password', 'password'],
    ['show', 'show password'], ['next', 'next button']
  ];

  const SAMPLE_FIRST = ['John','Michael','Somer','David','James','Robert','William','Daniel','Joseph','Thomas','Charles','Andrew','Henry','Samuel','Benjamin','Lucas','Mason','Ethan','Noah','Liam','Oliver','Elijah','Logan','Jacob','Aiden','Jackson','Sebastian','Caleb','Owen','Wyatt','Emma','Olivia','Sophia','Isabella','Mia','Amelia','Harper','Evelyn','Abigail','Emily','Ella','Grace','Chloe','Lily','Hannah','Natalie','Zoe','Nora','Layla','Violet'];
  const SAMPLE_LAST = ['Smith','Jordan','Brown','Miller','Johnson','Williams','Jones','Davis','Garcia','Wilson','Anderson','Taylor','Moore','Jackson','Martin','Lee','Thompson','White','Harris','Clark','Lewis','Robinson','Walker','Young','Allen','King','Wright','Scott','Torres','Nguyen','Hill','Green','Adams','Baker','Nelson','Carter','Mitchell','Perez','Roberts','Turner','Phillips','Campbell','Parker','Evans','Edwards','Collins','Stewart','Morris','Rogers','Reed'];

  const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const lines = (s) => [...new Set(s.split(/\r?\n/).map((x) => x.trim()).filter(Boolean))];
  const get = async (k) => (await chrome.storage.local.get(k))[k];

  let myTab = null;
  try { myTab = (await chrome.runtime.sendMessage({ type: 'whoami' })).tabId; } catch (e) {}
  const ui0 = await get(UI_KEY);
  if (!ui0 || !ui0.open || ui0.tabId !== myTab) { window.__mailerPanel = false; return; }

  /* ---------- markup + styles (inside a shadow root so the page cannot touch it) ---------- */
  const host = document.createElement('div');
  host.id = 'mailer-by-jass-host';
  host.style.cssText = 'all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });

  root.innerHTML = `
<style>
  :host { all: initial; }
  * { box-sizing: border-box; margin: 0; padding: 0; border-radius: 0; text-transform: lowercase;
      font-family: ui-monospace, "SF Mono", "Cascadia Mono", "JetBrains Mono", Menlo, Consolas, "Courier New", monospace; }
  input, textarea { text-transform: none; }
  .box {
    position: fixed; width: 340px; max-height: calc(100vh - 16px); overflow-y: auto; overflow-x: hidden;
    color: #000; font-size: 12px; line-height: 1.5; letter-spacing: 0;
    background-color: #fff;
    background-image: radial-gradient(rgba(0,0,0,.28) 1px, transparent 1.3px);
    background-size: 14px 14px; background-position: 7px 7px;
    border: 2px solid #000; box-shadow: 5px 5px 0 #000;
  }
  .bar { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px;
         padding: 9px 10px 8px; border-bottom: 2px solid #000; cursor: move; user-select: none; touch-action: none;
         background: rgba(255,255,255,.9); }
  .brand b { font-size: 19px; font-weight: 800; letter-spacing: -.5px; }
  .brand b span { font-size: 12px; font-weight: 700; margin-left: 1px; }
  .brand i { display: block; font-style: normal; font-size: 10px; margin-top: 1px; }
  .wbtns { display: flex; gap: 4px; }
  .wbtns button { width: 22px; height: 22px; border: 1.5px solid #000; background: #fff; color: #000; font-size: 13px; line-height: 1; cursor: pointer; }
  .wbtns button:hover { background: #000; color: #fff; }
  .body { padding: 10px; }
  .collapsed .body { display: none; }
  .collapsed .bar { border-bottom: 0; }

  .tabs { display: flex; margin-bottom: 10px; }
  .tab { flex: 1; padding: 5px 0; border: 1.5px solid #000; background: #fff; color: #000; cursor: pointer; font-size: 12px; font-weight: 700; position: relative; }
  .tab + .tab { border-left: 0; }
  .tab.on { background: #000; color: #fff; }
  .tab i { display: inline-block; width: 6px; height: 6px; margin-left: 5px; background: #000; vertical-align: middle; }
  .tab.on i { background: #fff; }
  .tab i[hidden] { display: none; }
  .pane[hidden] { display: none; }

  button.big { width: 100%; padding: 9px 0; border: 2px solid #000; background: #000; color: #fff; font-size: 13px; font-weight: 800; cursor: pointer; box-shadow: 3px 3px 0 rgba(0,0,0,.35); }
  button.big:hover { background: #fff; color: #000; }
  button.big:active { transform: translate(2px, 2px); box-shadow: 1px 1px 0 rgba(0,0,0,.35); }
  button.big:disabled { background: #fff; color: #000; border-style: dashed; cursor: default; box-shadow: none; transform: none; }
  .row { display: flex; gap: 6px; }
  button.stop { padding: 0 12px; border: 2px solid #000; background: #fff; color: #000; font-size: 12px; font-weight: 800; cursor: pointer; }
  button.stop:hover { background: #000; color: #fff; }
  button.stop[hidden] { display: none; }
  button.link { background: none; border: 0; color: #000; text-decoration: underline; cursor: pointer; font-size: 11px; padding: 2px 0 6px; }

  .profile { margin-top: 10px; padding: 6px 8px; border: 1.5px dashed #000; background: rgba(255,255,255,.88); }
  .profile[hidden] { display: none; }
  .profile b { font-weight: 800; word-break: break-all; }
  ol.steps { list-style: none; margin-top: 10px; border: 1.5px solid #000; background: rgba(255,255,255,.88); }
  ol.steps li { display: flex; gap: 6px; padding: 3px 7px; border-bottom: 1px dotted #000; }
  ol.steps li:last-child { border-bottom: 0; }
  ol.steps .n { flex: 0 0 18px; }
  ol.steps .mk { flex: 0 0 22px; white-space: pre; }
  ol.steps .t { flex: 1; min-width: 0; }
  ol.steps .t small { display: block; font-size: 10px; opacity: .75; word-break: break-word; }
  ol.steps li.pending { opacity: .55; }
  ol.steps li.active { background: #000; color: #fff; }
  ol.steps li.active .mk { animation: blink 1s steps(1) infinite; }
  ol.steps li.error { text-decoration: underline wavy; text-underline-offset: 3px; }
  @keyframes blink { 50% { opacity: .2; } }

  .result { margin-top: 10px; padding: 8px 9px; border: 2px solid #000; background: #fff; font-weight: 700; }
  .result[hidden] { display: none; }
  .result.qr, .result.unknown, .result.error { border-style: dashed; }
  .hint { margin-top: 10px; font-size: 10px; opacity: .7; }

  label.l { display: block; margin: 9px 0 3px; font-size: 11px; font-weight: 800; }
  label.l em { font-style: normal; font-weight: 400; }
  label.l small { font-weight: 400; }
  input, textarea { width: 100%; padding: 6px 7px; border: 1.5px solid #000; background: #fff; color: #000; font-size: 12px; outline: none; }
  input:focus, textarea:focus { box-shadow: 2px 2px 0 #000; }
  input::placeholder, textarea::placeholder { color: #777; }
  textarea { height: 112px; resize: vertical; line-height: 1.45; }
  .two { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .yrs { display: flex; align-items: center; gap: 8px; }
  details { margin: 10px 0; font-size: 11px; }
  details summary { cursor: pointer; font-weight: 700; }
  details p { margin: 5px 0; font-size: 10px; opacity: .75; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
  .grid input { font-size: 11px; padding: 4px 6px; }
  .msg { margin-top: 8px; padding: 6px 8px; border: 1.5px solid #000; background: #fff; font-weight: 700; }
  .msg.bad { border-style: dashed; }
  .msg[hidden] { display: none; }

  .modal { position: absolute; inset: 0; display: grid; place-items: center; padding: 14px; background: rgba(255,255,255,.88); }
  .modal[hidden] { display: none; }
  .modal .mb { width: 100%; padding: 12px; border: 2px solid #000; background: #fff; box-shadow: 4px 4px 0 #000; }
  .modal h2 { font-size: 13px; margin-bottom: 6px; }
  .modal p { margin-bottom: 10px; }
</style>
<div class="box" id="box">
  <div class="bar" id="bar">
    <div class="brand"><b>mailer<span>.com</span></b><i>by jass</i></div>
    <div class="wbtns"><button id="min" title="minimise">_</button><button id="x" title="close">x</button></div>
  </div>
  <div class="body">
    <nav class="tabs"><button class="tab on" data-tab="run">run</button><button class="tab" data-tab="data">data<i id="dirty" hidden></i></button></nav>

    <section id="tab-run" class="pane">
      <div class="row"><button id="runBtn" class="big">run automation</button><button id="stopBtn" class="stop" hidden>stop</button></div>
      <div id="profile" class="profile" hidden></div>
      <ol id="steps" class="steps"></ol>
      <div id="result" class="result" hidden></div>
      <p class="hint">// stays on the page while it runs. click the extension icon to close it. drag the top bar to move it.</p>
    </section>

    <section id="tab-data" class="pane" hidden>
      <label class="l">sign-up page link <small>(step 1)</small></label>
      <input id="url" type="text" spellcheck="false" placeholder="https://your-demo-site/signup">
      <div class="two">
        <div><label class="l">first names <em id="cntFirst">(0)</em></label><textarea id="first" spellcheck="false" placeholder="John&#10;Michael&#10;Somer&#10;David"></textarea></div>
        <div><label class="l">last names <em id="cntLast">(0)</em></label><textarea id="last" spellcheck="false" placeholder="Smith&#10;Jordan&#10;Brown&#10;Miller"></textarea></div>
      </div>
      <button id="sample" class="link" type="button">load 50 + 50 sample names</button>
      <label class="l">birth year range <small>(month &amp; day are random)</small></label>
      <div class="yrs"><input id="yFrom" type="number" min="1900" max="2100" placeholder="1992"><span>to</span><input id="yTo" type="number" min="1900" max="2100" placeholder="2003"></div>
      <label class="l">password <small>(hover to reveal)</small></label>
      <input id="pass" type="password" autocomplete="off" spellcheck="false" placeholder="********">
      <details><summary>advanced: css selectors (optional)</summary>
        <p>leave empty to auto-detect fields. fill only if your demo page is not detected.</p>
        <div class="grid" id="selGrid"></div>
      </details>
      <button id="save" class="big">save data</button>
      <div id="saveMsg" class="msg" hidden></div>
    </section>
  </div>
  <div id="modal" class="modal" hidden>
    <div class="mb">
      <h2>set up your data first</h2>
      <p>add the sign-up link, names, birth years and password in the data tab, then press "save data". after that the automation is ready.</p>
      <button id="modalOk" class="big">go to data</button>
    </div>
  </div>
</div>`;

  const $ = (id) => root.getElementById(id);
  const box = $('box');
  const selGrid = $('selGrid');
  SEL_KEYS.forEach(([k, label]) => {
    const i = document.createElement('input');
    i.dataset.sel = k;
    i.placeholder = label;
    i.spellcheck = false;
    selGrid.appendChild(i);
  });
  const selInput = (k) => root.querySelector(`[data-sel="${k}"]`);

  // keep keystrokes inside the box (pages often grab keys)
  ['keydown', 'keyup', 'keypress'].forEach((t) => host.addEventListener(t, (e) => e.stopPropagation()));
  document.documentElement.appendChild(host);

  /* ---------- position, drag, collapse ---------- */
  const clamp = (x, y) => {
    const w = box.offsetWidth || 340;
    const h = Math.min(box.offsetHeight || 200, window.innerHeight);
    return [Math.min(Math.max(0, x), Math.max(0, window.innerWidth - w)), Math.min(Math.max(0, y), Math.max(0, window.innerHeight - 40 > h ? window.innerHeight - h : window.innerHeight - 40))];
  };
  function place(x, y) {
    const [cx, cy] = clamp(x, y);
    box.style.left = cx + 'px';
    box.style.top = cy + 'px';
    return [cx, cy];
  }
  place(ui0.x != null ? ui0.x : window.innerWidth - 360, ui0.y != null ? ui0.y : 16);
  box.classList.toggle('collapsed', !!ui0.collapsed);

  async function saveUi(patch) {
    const cur = (await get(UI_KEY)) || {};
    await chrome.storage.local.set({ [UI_KEY]: Object.assign({}, cur, patch) });
  }

  const bar = $('bar');
  let drag = null;
  bar.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.wbtns')) return;
    const r = box.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    bar.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  bar.addEventListener('pointermove', (e) => { if (drag) place(e.clientX - drag.dx, e.clientY - drag.dy); });
  const endDrag = async () => {
    if (!drag) return;
    drag = null;
    const r = box.getBoundingClientRect();
    await saveUi({ x: Math.round(r.left), y: Math.round(r.top) });
  };
  bar.addEventListener('pointerup', endDrag);
  bar.addEventListener('pointercancel', endDrag);
  window.addEventListener('resize', onResize);
  function onResize() { const r = box.getBoundingClientRect(); place(r.left, r.top); }

  $('min').addEventListener('click', async () => {
    const c = !box.classList.contains('collapsed');
    box.classList.toggle('collapsed', c);
    await saveUi({ collapsed: c });
  });
  $('x').addEventListener('click', () => saveUi({ open: false }));

  function destroy() {
    window.removeEventListener('resize', onResize);
    chrome.storage.onChanged.removeListener(onStorage);
    host.remove();
    window.__mailerPanel = false;
  }

  /* ---------- tabs ---------- */
  function showTab(name) {
    root.querySelectorAll('.tab').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    $('tab-run').hidden = name !== 'run';
    $('tab-data').hidden = name !== 'data';
  }
  root.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => showTab(b.dataset.tab)));

  /* ---------- data tab ---------- */
  let savedSnapshot = '';
  function readForm() {
    const sel = {};
    SEL_KEYS.forEach(([k]) => { const v = selInput(k).value.trim(); if (v) sel[k] = v; });
    return {
      url: $('url').value.trim(),
      first: lines($('first').value),
      last: lines($('last').value),
      yearFrom: parseInt($('yFrom').value, 10),
      yearTo: parseInt($('yTo').value, 10),
      password: $('pass').value,
      sel
    };
  }
  function writeForm(d) {
    $('url').value = d.url || '';
    $('first').value = (d.first || []).join('\n');
    $('last').value = (d.last || []).join('\n');
    $('yFrom').value = d.yearFrom || '';
    $('yTo').value = d.yearTo || '';
    $('pass').value = d.password || '';
    SEL_KEYS.forEach(([k]) => { selInput(k).value = (d.sel && d.sel[k]) || ''; });
    updateCounts();
  }
  function updateCounts() {
    $('cntFirst').textContent = '(' + lines($('first').value).length + ')';
    $('cntLast').textContent = '(' + lines($('last').value).length + ')';
  }
  const snapshot = () => JSON.stringify(readForm());
  const refreshDirty = () => { $('dirty').hidden = snapshot() === savedSnapshot; };
  root.querySelectorAll('#tab-data input, #tab-data textarea').forEach((el) =>
    el.addEventListener('input', () => { updateCounts(); refreshDirty(); })
  );

  const pass = $('pass');                       // password is only visible while hovering
  pass.addEventListener('mouseenter', () => { pass.type = 'text'; });
  pass.addEventListener('mouseleave', () => { pass.type = 'password'; });

  $('sample').addEventListener('click', () => {
    $('first').value = SAMPLE_FIRST.join('\n');
    $('last').value = SAMPLE_LAST.join('\n');
    updateCounts();
    refreshDirty();
  });

  function validate(d) {
    if (!/^(https?|file):\/\//i.test(d.url)) return 'enter the sign-up page link (starting with http://, https:// or file://).';
    if (!d.first.length) return 'add at least one first name (about 50 is ideal).';
    if (!d.last.length) return 'add at least one last name (about 50 is ideal).';
    if (!(d.yearFrom >= 1900 && d.yearTo <= 2100 && d.yearFrom <= d.yearTo)) return 'enter a valid birth year range, e.g. 1992 to 2003.';
    if (!d.password) return 'enter the password to use.';
    return null;
  }
  let flashT;
  function flash(cls, text) {
    const el = $('saveMsg');
    el.className = 'msg ' + cls;
    el.textContent = text;
    el.hidden = false;
    clearTimeout(flashT);
    flashT = setTimeout(() => { el.hidden = true; }, 4500);
  }
  $('save').addEventListener('click', async () => {
    const d = readForm();
    const err = validate(d);
    if (err) return flash('bad', '[!] ' + err);
    d.saved = true;
    await chrome.storage.local.set({ [DATA_KEY]: d });
    savedSnapshot = snapshot();
    refreshDirty();
    $('save').textContent = 'update data';
    flash('ok', `[ok] saved: ${d.first.length} first, ${d.last.length} last, years ${d.yearFrom}-${d.yearTo}. ready to run.`);
  });

  /* ---------- run tab ---------- */
  function makeProfile(d) {
    const first = pick(d.first);
    const last = pick(d.last);
    const base = (first + last).toLowerCase().replace(/[^a-z0-9]/g, '');
    const digits = Math.random() < 0.5 ? rnd(1000, 9999) : rnd(10000, 99999);
    return {
      first, last, base, digits,
      username: base + digits,
      month: rnd(1, 12),
      day: rnd(1, 28),
      year: rnd(d.yearFrom, d.yearTo),
      gender: Math.random() < 0.5 ? 'male' : 'female',
      attempts: 0
    };
  }

  $('runBtn').addEventListener('click', async () => {
    const d = await get(DATA_KEY);
    if (!d || !d.saved || validate(d)) { $('modal').hidden = false; return; }
    const run = {
      active: true,
      tabId: myTab,
      step: 0,
      cur: 0,
      st: STEP_LABELS.map(() => 'pending'),
      notes: {},
      prof: makeProfile(d),
      data: { password: d.password, sel: d.sel || {} },
      result: null,
      error: null,
      startedAt: Date.now()
    };
    await chrome.storage.local.set({ [RUN_KEY]: run });
    chrome.runtime.sendMessage({ type: 'navigate', url: d.url });   // step 1: open the link
  });

  $('stopBtn').addEventListener('click', async () => {
    const r = await get(RUN_KEY);
    if (!r) return;
    r.active = false;
    r.result = { kind: 'error', message: 'stopped.' };
    await chrome.storage.local.set({ [RUN_KEY]: r });
  });

  $('modalOk').addEventListener('click', () => { $('modal').hidden = true; showTab('data'); });

  function renderResult(res) {
    const el = $('result');
    if (!res) { el.hidden = true; return; }
    el.hidden = false;
    el.className = 'result ' + res.kind;
    const tag = { success: '[ok] ', qr: '[x] ', unknown: '[?] ', error: '[!] ' }[res.kind] || '';
    el.textContent = tag + res.message;
  }

  function render(run) {
    const list = $('steps');
    list.innerHTML = '';
    const mark = { pending: '[ ]', active: '[>]', done: '[x]', error: '[!]' };
    STEP_LABELS.forEach((label, i) => {
      const st = (run && run.st && run.st[i]) || 'pending';
      const li = document.createElement('li');
      li.className = st;
      const n = document.createElement('span'); n.className = 'n'; n.textContent = String(i + 1).padStart(2, '0');
      const m = document.createElement('span'); m.className = 'mk'; m.textContent = mark[st];
      const t = document.createElement('span'); t.className = 't'; t.textContent = label;
      if (run && run.notes && run.notes[i]) {
        const s = document.createElement('small');
        s.textContent = '> ' + run.notes[i];
        t.appendChild(s);
      }
      li.append(n, m, t);
      list.appendChild(li);
    });

    const running = !!(run && run.active);
    $('runBtn').disabled = running;
    $('runBtn').textContent = running ? 'running...' : 'run automation';
    $('stopBtn').hidden = !running;

    const p = $('profile');
    if (run && run.prof) {
      const x = run.prof;
      p.hidden = false;
      p.innerHTML = '';
      [['name', `${x.first} ${x.last}`], ['user', `${x.username}@demomail.com`], ['born', `${x.month}/${x.day}/${x.year} / ${x.gender}`]].forEach(([k, v]) => {
        const d = document.createElement('div');
        d.append(k + ': ');
        const b = document.createElement('b');
        b.textContent = v;
        d.appendChild(b);
        p.appendChild(d);
      });
    } else {
      p.hidden = true;
    }
    renderResult(run ? run.result : null);
  }

  function onStorage(changes, area) {
    if (area !== 'local') return;
    if (changes[RUN_KEY]) render(changes[RUN_KEY].newValue);
    if (changes[UI_KEY]) {
      const u = changes[UI_KEY].newValue;
      if (!u || !u.open || u.tabId !== myTab) destroy();
    }
  }
  chrome.storage.onChanged.addListener(onStorage);

  /* ---------- init ---------- */
  const [d, run] = await Promise.all([get(DATA_KEY), get(RUN_KEY)]);
  if (d) { writeForm(d); $('save').textContent = 'update data'; }
  savedSnapshot = snapshot();
  refreshDirty();
  render(run);
})();
