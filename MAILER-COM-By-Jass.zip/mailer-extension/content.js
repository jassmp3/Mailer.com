// mailer.com by jass - automation engine (runs inside the demo sign-up page).
// state lives in chrome.storage.local ("mr_run") so it survives page navigations.
(() => {
  if (window.__mailerLoop) return;
  window.__mailerLoop = true;

  const KEY = 'mr_run';
  const STOP = 'STOPPED';
  const GAP = 350; // pause between steps (ms)
  const LAST = 10; // index of the final step (11 steps: 0..10)
  const MONTHS = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rnd = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;

  let SEL = {};   // optional css-selector overrides from the data tab
  let DATA = {};

  /* ---------- storage helpers ---------- */
  const getRun = async () => (await chrome.storage.local.get(KEY))[KEY];

  async function patch(fn) {
    const r = await getRun();
    if (!r || !r.active) throw new Error(STOP);
    fn(r);
    await chrome.storage.local.set({ [KEY]: r });
    return r;
  }
  const begin = (i) => patch((r) => { r.st[i] = 'active'; r.cur = i; });
  const done = (i, note) => patch((r) => { r.st[i] = 'done'; r.step = i + 1; if (note) r.notes[i] = note; });

  async function failRun(i, message) {
    const r = await getRun();
    if (!r) return;
    r.active = false;
    if (i != null) r.st[i] = 'error';
    r.error = message;
    r.result = { kind: 'error', message };
    await chrome.storage.local.set({ [KEY]: r });
  }

  async function waitFor(fn, ms, what) {
    const t0 = Date.now();
    for (;;) {
      const v = fn();
      if (v) return v;
      if (Date.now() - t0 > ms) throw new Error('could not find ' + what + ' on this page');
      await sleep(250);
      const r = await getRun();
      if (!r || !r.active) throw new Error(STOP);
    }
  }

  /* ---------- dom helpers ---------- */
  function isVisible(el) {
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      if (n.hidden) return false;
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    }
    return true;
  }
  const isDisabled = (el) => el.disabled || el.getAttribute('aria-disabled') === 'true';

  const norm = (s) =>
    String(s || '')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/[_\-\[\].:]+/g, ' ')
      .replace(/\s+/g, ' ')
      .toLowerCase();

  function desc(el) {
    const p = [el.name, el.id, el.placeholder, el.getAttribute('aria-label'), el.getAttribute('autocomplete'), el.getAttribute('data-testid'), el.getAttribute('data-field'), el.getAttribute('title')];
    if (el.labels) for (const l of el.labels) p.push(l.textContent);
    const lb = el.getAttribute('aria-labelledby');
    if (lb) lb.split(/\s+/).forEach((id) => { const n = document.getElementById(id); if (n) p.push(n.textContent); });
    const wrap = el.closest('label');
    if (wrap) p.push(wrap.textContent);
    return norm(p.filter(Boolean).join(' '));
  }

  const RX = {
    first: /\b(first ?name|given name|fname|first)\b/,
    last: /\b(last ?name|family name|surname|lname|last)\b/,
    month: /\b(month|mm)\b/,
    day: /\b(day|dd)\b/,
    year: /\b(year|yyyy)\b/,
    gender: /\b(gender|sex)\b/,
    user: /\b(user ?name|username|login|email|handle)\b/
  };
  const TEXT_TYPES = ['', 'text', 'email', 'search', 'tel', 'number'];

  function override(kind) {
    if (!SEL[kind]) return undefined;
    const el = document.querySelector(SEL[kind]);
    return el && isVisible(el) ? el : null;
  }

  function find(kind) {
    const o = override(kind);
    if (o !== undefined) return o;
    const all = [...document.querySelectorAll('input,select,textarea,[role=combobox]')].filter(isVisible);
    const ok = (e) => {
      const t = (e.getAttribute('type') || '').toLowerCase();
      if (e.tagName === 'INPUT' && !TEXT_TYPES.includes(t)) return false;
      return true;
    };
    return all.find((e) => ok(e) && RX[kind].test(desc(e))) || null;
  }

  function findGenderRadios() {
    const r = [...document.querySelectorAll('input[type=radio]')].filter(isVisible);
    return r.filter((e) => /male|female|gender|sex/.test(desc(e) + ' ' + norm(e.value)));
  }

  function findPass() {
    const o = override('password');
    if (o !== undefined) return o;
    const all = [...document.querySelectorAll('input')].filter(isVisible);
    const pw = all.filter((e) => e.type === 'password' || (['text', ''].includes(e.type) && /pass/.test(desc(e)) && !/show|reveal/.test(desc(e))));
    return pw.length ? pw : null;
  }

  function findShow() {
    const o = override('show');
    if (o !== undefined) return o;
    const cb = [...document.querySelectorAll('input[type=checkbox]')].filter(isVisible).find((e) => /show|reveal/.test(desc(e)));
    if (cb) return cb;
    return [...document.querySelectorAll('button,[role=button],label,span')].filter(isVisible)
      .find((e) => /^\s*(show( password)?|show.{0,12}pass.*)\s*$/i.test(e.textContent || '')) || null;
  }

  function findNext() {
    const o = override('next');
    if (o !== undefined) return o && !isDisabled(o) ? o : null;
    const c = [...document.querySelectorAll('button,input[type=submit],input[type=button],[role=button],a')].filter((e) => isVisible(e) && !isDisabled(e));
    const txt = (e) => (e.tagName === 'INPUT' ? e.value : e.textContent || '').trim();
    return c.find((e) => /^next$/i.test(txt(e))) || c.find((e) => /^(next|continue|proceed|sign ?up|create|submit|register)\b/i.test(txt(e))) || null;
  }

  // the "create your own username" choice that sometimes sits under the suggested usernames
  const OWN_RX = /(create|make|choose|pick|use|enter|type)\s+(a\s+|an\s+|your\s+|my\s+)?(own|new|custom|different)\b|\b(own|new|custom|different)\s+(user ?name|address|email)\b|create\s+.{0,20}(user ?name|address|email)/i;
  function findCreateOwn() {
    const o = override('create');
    if (o !== undefined) return o;
    const c = [...document.querySelectorAll('button,a,label,li,[role=radio],[role=option],[role=button],[role=menuitem],input[type=radio]')].filter(isVisible);
    const txt = (e) => {
      if (e.tagName === 'INPUT') return desc(e) + ' ' + norm(e.value);
      return (e.textContent || '').replace(/\s+/g, ' ').trim();
    };
    const hits = c.filter((e) => { const t = txt(e); return t.length > 0 && t.length <= 70 && OWN_RX.test(t); });
    // prefer the most specific (shortest) match; radios/labels beat bare containers
    hits.sort((a, b) => txt(a).length - txt(b).length);
    return hits[0] || null;
  }

  function ownTextMatch(rx) {
    for (const el of document.body.querySelectorAll('*')) {
      if (['SCRIPT', 'STYLE', 'NOSCRIPT'].includes(el.tagName)) continue;
      let own = '';
      for (const n of el.childNodes) if (n.nodeType === 3) own += n.nodeValue;
      if (own && rx.test(own) && isVisible(el)) return el;
    }
    return null;
  }
  const taken = () => ownTextMatch(/\b(taken|not available|unavailable|already (in use|exists|registered|taken)|in use)\b/i);

  /* ---------- setters ---------- */
  function setVal(el, v) {
    el.focus();
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, String(v));
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  const PLACEHOLDER = /^(select|choose|pick|-+|month|day|year|gender|sex|dd|mm|yyyy)\b/i;

  async function fillDropdown(el, test) {
    if (el.tagName === 'SELECT') {
      const valid = [...el.options].filter((o) => !o.disabled && o.value !== '' && !PLACEHOLDER.test(o.textContent.trim()));
      if (!valid.length) throw new Error('dropdown has no options');
      const o = (test && valid.find((x) => test(x.textContent.trim(), x.value))) || valid[rnd(0, valid.length - 1)];
      el.value = o.value;
      o.selected = true;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return;
    }
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') return; // caller types into it
    // custom (div-based) dropdown
    el.click();
    await sleep(250);
    const opts = [...document.querySelectorAll('[role=option],[role=menuitem],ul[role=listbox] li')].filter(isVisible);
    if (!opts.length) throw new Error('custom dropdown did not open');
    const o = (test && opts.find((x) => test(x.textContent.trim(), x.getAttribute('data-value') || ''))) || opts[rnd(0, opts.length - 1)];
    o.click();
    await sleep(120);
  }

  async function fillField(kind, el, value, test) {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') setVal(el, value);
    else await fillDropdown(el, test);
  }

  /* ---------- username page helpers ---------- */
  const userReady = () => {
    const u = find('user');
    return u && !isDisabled(u) && !u.readOnly ? u : null;
  };

  // returns the editable username field; clicks "create your own" first if the page asks for it
  async function ensureUserField(ms) {
    const t0 = Date.now();
    let clicks = 0, lastClick = 0, usedOwn = false;
    for (;;) {
      const u = userReady();
      if (u) return { el: u, usedOwn };
      const c = findCreateOwn();
      if (c && clicks < 3 && Date.now() - lastClick > 2500) {
        c.scrollIntoView && c.scrollIntoView({ block: 'center' });
        c.click();
        clicks++;
        usedOwn = true;
        lastClick = Date.now();
        await sleep(350);
        continue;
      }
      if (Date.now() - t0 > ms) throw new Error('could not find the username field' + (c ? ' even after clicking "create your own"' : ' or a "create your own" option'));
      await sleep(250);
      const r = await getRun();
      if (!r || !r.active) throw new Error(STOP);
    }
  }

  function newDigits(prof) {
    prof.digits = Math.random() < 0.5 ? rnd(1000, 9999) : rnd(10000, 99999);
    prof.username = prof.base + prof.digits;
    prof.attempts = (prof.attempts || 0) + 1;
  }

  /* ---------- steps ---------- */
  const steps = [];

  // 1. open the sign-up link (the panel already navigated this tab)
  steps[0] = async () => { await begin(0); await sleep(200); await done(0, 'page loaded'); };

  // 2. first + last name
  steps[1] = async (run) => {
    await begin(1);
    const f = await waitFor(() => find('first'), 20000, 'the first-name field');
    const l = await waitFor(() => find('last'), 5000, 'the last-name field');
    setVal(f, run.prof.first);
    setVal(l, run.prof.last);
    await done(1, run.prof.first + ' ' + run.prof.last);
  };

  const clickNext = (i) => async () => {
    await begin(i);
    const btn = await waitFor(findNext, 20000, 'an enabled next button');
    await done(i);          // save progress first: the click may reload the page
    await sleep(120);
    btn.scrollIntoView && btn.scrollIntoView({ block: 'center' });
    btn.click();
  };
  steps[2] = clickNext(2);

  // 4. birthday + gender
  steps[3] = async (run) => {
    await begin(3);
    const p = run.prof;
    const m = await waitFor(() => find('month'), 20000, 'the birth-month field');
    const d = await waitFor(() => find('day'), 5000, 'the birth-day field');
    const y = await waitFor(() => find('year'), 5000, 'the birth-year field');

    await fillField('month', m, p.month, (t, v) => v === String(p.month) || parseInt(t, 10) === p.month || t.toLowerCase().startsWith(MONTHS[p.month - 1].slice(0, 3)));
    await fillField('day', d, p.day, (t, v) => v === String(p.day) || parseInt(t, 10) === p.day);
    await fillField('year', y, p.year, (t, v) => v === String(p.year) || t === String(p.year));

    const wantMale = p.gender === 'male';
    const gTest = (t) => {
      const s = t.toLowerCase();
      if (/prefer|rather|other|custom|not/.test(s)) return false;
      return wantMale ? /(^|[^a-z])(male|man)$/.test(s.trim()) || s.trim() === 'm' : /(female|woman)$/.test(s.trim()) || s.trim() === 'f';
    };
    let g = override('gender');
    if (g === undefined) g = find('gender');
    if (g) {
      await fillField('gender', g, p.gender, gTest);
    } else {
      const radios = findGenderRadios();
      if (radios.length) {
        const r = radios.find((e) => gTest(norm(e.value) + '') || gTest(desc(e).split(' ').pop())) || radios[rnd(0, radios.length - 1)];
        r.click();
      }
    }
    await done(3, `${MONTHS[p.month - 1]} ${p.day}, ${p.year} · ${p.gender}`);
  };
  steps[4] = clickNext(4);

  // 6. username page: it either asks for the username directly, or shows suggestions
  //    with a "create your own" option - click that one so the username box appears
  steps[5] = async () => {
    await begin(5);
    const { usedOwn } = await ensureUserField(25000);
    await done(5, usedOwn ? 'clicked "create your own username"' : 'username box shown directly');
  };

  // 7. type the username (first name + last name + 4/5 digits, nothing else)
  steps[6] = async () => {
    await begin(6);
    const first = await ensureUserField(15000);
    let f = first.el;
    for (let i = 0; i < 15; i++) {
      const r = await getRun();
      // an error already on screen before we type may be left over from the last submit,
      // so only a message that APPEARS after typing counts as a live "taken" warning
      const staleBefore = !!taken();
      setVal(f, r.prof.username);
      await sleep(900);
      if (staleBefore || !taken()) { await done(6, r.prof.username + (r.prof.attempts ? ` (try ${r.prof.attempts + 1})` : '')); return; }
      if ((r.prof.attempts || 0) >= 14) throw new Error('username kept coming back as taken');
      await patch((x) => { newDigits(x.prof); });
      f = (await ensureUserField(8000)).el;
    }
    throw new Error('could not find a free username');
  };

  // 8. click next; if the username is rejected, change only the digits and go again
  steps[7] = async () => {
    await begin(7);
    const btn = await waitFor(findNext, 20000, 'an enabled next button');
    const hadErr = !!taken();   // an old error may still be showing; give the page time to react
    await done(7);
    await sleep(120);
    btn.click();
    const t0 = Date.now();
    for (;;) {
      await sleep(350);
      const r = await getRun();
      if (!r || !r.active) throw new Error(STOP);
      if (findPass()) return;                       // moved on in the same page
      const u = find('user');
      const rejected = hadErr ? Date.now() - t0 > 2500 : !!taken();
      if (u && (rejected || Date.now() - t0 > 7000)) {
        if ((r.prof.attempts || 0) >= 14) throw new Error('username kept coming back as taken');
        await patch((x) => {
          newDigits(x.prof);
          x.st[6] = 'pending';
          x.st[7] = 'pending';
          x.step = 6;
          x.notes[7] = 'username rejected - trying other digits';
        });
        return;
      }
      if (Date.now() - t0 > 15000) return;
    }
  };

  // 9. tick "show password", then type the saved password
  steps[8] = async () => {
    await begin(8);
    await waitFor(findPass, 20000, 'the password field');
    const show = findShow();
    if (show) {
      if (show.type === 'checkbox') { if (!show.checked) show.click(); } else show.click();
      await sleep(250);
    }
    const fields = await waitFor(findPass, 5000, 'the password field');
    for (const f of [].concat(fields)) setVal(f, DATA.password);
    await done(8, show ? 'show password ticked' : 'no show-password option found');
  };
  steps[9] = clickNext(9);

  // 11. final check: qr page -> bad luck, phone-number page -> success
  const MSG = {
    success: 'congrats, you did it - successful! now enter the number from your sms portal and verify the account. don\'t forget to apply forwarding to your main mail account.',
    qr: 'bad luck, next time! the qr scanner page showed up instead of the phone-number page.',
    unknown: 'finished all steps, but i could not tell which final page appeared.'
  };
  steps[10] = async () => {
    await begin(10);
    const t0 = Date.now();
    let kind = 'unknown';
    while (Date.now() - t0 < 25000) {
      const phone = [...document.querySelectorAll('input')].filter(isVisible).find((e) => e.type === 'tel' || /phone|mobile|cell/.test(desc(e)));
      if (phone) { kind = 'success'; break; }
      if (ownTextMatch(/\bqr\b|qr.?code|scan/i)) { kind = 'qr'; break; }
      await sleep(300);
      const r = await getRun();
      if (!r || !r.active) throw new Error(STOP);
    }
    await patch((r) => {
      r.st[10] = kind === 'qr' ? 'error' : 'done';
      r.step = 11;
      r.active = false;
      r.result = { kind, message: MSG[kind] };
    });
  };

  /* ---------- main loop ---------- */
  (async () => {
    let me;
    try { me = await chrome.runtime.sendMessage({ type: 'whoami' }); } catch (e) { return; }
    const myTab = me && me.tabId;
    for (;;) {
      const run = await getRun();
      if (!run || !run.active || run.tabId !== myTab || run.step > LAST) return;
      DATA = run.data || {};
      SEL = DATA.sel || {};
      const i = run.step;
      try {
        await steps[i](run);
      } catch (e) {
        if (e && e.message === STOP) return;
        await failRun(i, (e && e.message) || 'unknown error');
        return;
      }
      await sleep(GAP);
    }
  })();
})();
