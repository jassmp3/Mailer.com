// mailer.com by jass - background service worker
// - the toolbar icon opens / closes the movable box inside the current page
// - re-injects the box and the automation after every page load while they are needed

const UI_KEY = 'mr_ui';
const RUN_KEY = 'mr_run';

async function getLocal(k) {
  return (await chrome.storage.local.get(k))[k];
}

function flashBadge(tabId, text) {
  chrome.action.setBadgeText({ text, tabId });
  chrome.action.setBadgeBackgroundColor({ color: '#000000', tabId });
  setTimeout(() => chrome.action.setBadgeText({ text: '', tabId }), 3000);
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id == null) return;
  const ui = (await getLocal(UI_KEY)) || {};

  // is the box really on this page right now?
  let exists = false;
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => !!window.__mailerPanel });
    exists = !!(r && r[0] && r[0].result);
  } catch (e) {
    flashBadge(tab.id, 'x');   // chrome://, web store, new-tab page ... cannot hold the box
    return;
  }

  if (ui.open && ui.tabId === tab.id && exists) {
    await chrome.storage.local.set({ [UI_KEY]: { ...ui, open: false } });   // second click closes it
    return;
  }

  await chrome.storage.local.set({ [UI_KEY]: { ...ui, open: true, tabId: tab.id } });
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['panel.js'] });
  } catch (e) {
    await chrome.storage.local.set({ [UI_KEY]: { ...ui, open: false } });
    flashBadge(tab.id, 'x');
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return false;
  if (msg.type === 'whoami') {
    sendResponse({ tabId: sender.tab ? sender.tab.id : null });
  } else if (msg.type === 'navigate' && sender.tab) {
    chrome.tabs.update(sender.tab.id, { url: msg.url });
    sendResponse({ ok: true });
  }
  return false;
});

chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  if (info.status !== 'complete') return;
  const [ui, run] = await Promise.all([getLocal(UI_KEY), getLocal(RUN_KEY)]);
  if (ui && ui.open && ui.tabId === tabId) {
    try { await chrome.scripting.executeScript({ target: { tabId }, files: ['panel.js'] }); } catch (e) {}
  }
  if (run && run.active && run.tabId === tabId) {
    try { await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }); } catch (e) {}
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const ui = await getLocal(UI_KEY);
  if (ui && ui.open && ui.tabId === tabId) await chrome.storage.local.set({ [UI_KEY]: { ...ui, open: false } });
});
